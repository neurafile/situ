#[doc(hidden)]
#[derive(Eq, PartialEq, Debug)]
pub enum ATNType {
    LEXER = 0,
    PARSER,
}
